package com.taketwo.backend.repository;

import com.taketwo.backend.entity.MovieLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface MovieLogRepository extends JpaRepository<MovieLog, UUID> {
    List<MovieLog> findByUser_IdOrderByWatchedDateDesc(UUID userId);
}
