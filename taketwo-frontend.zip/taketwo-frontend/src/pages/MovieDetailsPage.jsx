import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import LogMovieModal from '../components/LogMovieModal.jsx';
import * as movieService from '../services/movieService';
import styles from './MovieDetailsPage.module.css';

export default function MovieDetailsPage() {
  const { tmdbId } = useParams();
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  const [movie, setMovie] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [logModalOpen, setLogModalOpen] = useState(false);
  const [loggedConfirmation, setLoggedConfirmation] = useState(false);

  // We don't yet have a "is this on my watchlist" lookup endpoint, so this
  // starts unknown and only reflects state once the user actually toggles it.
  const [onWatchlist, setOnWatchlist] = useState(null);
  const [watchlistBusy, setWatchlistBusy] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError('');

    movieService.getMovieDetails(tmdbId)
      .then((data) => { if (!cancelled) setMovie(data); })
      .catch(() => { if (!cancelled) setError('Could not load this movie.'); })
      .finally(() => { if (!cancelled) setLoading(false); });

    return () => { cancelled = true; };
  }, [tmdbId]);

  useEffect(() => {
    if (!isAuthenticated) return;
    let cancelled = false;
    movieService.getWatchlistStatus(tmdbId)
      .then((status) => { if (!cancelled) setOnWatchlist(status); })
      .catch(() => {});
    return () => { cancelled = true; };
  }, [tmdbId, isAuthenticated]);

  function requireAuth() {
    if (!isAuthenticated) {
      navigate('/login');
      return false;
    }
    return true;
  }

  function handleLogClick() {
    if (requireAuth()) setLogModalOpen(true);
  }

  async function handleWatchlistToggle() {
    if (!requireAuth()) return;
    setWatchlistBusy(true);
    try {
      const result = await movieService.toggleWatchlist(movie.tmdbId);
      setOnWatchlist(result.onWatchlist);
    } catch {
      // Leave state as-is; the button label will just reflect the last known state.
    } finally {
      setWatchlistBusy(false);
    }
  }

  if (loading) return <div className={styles.page}><p className={styles.state}>Loading…</p></div>;
  if (error || !movie) return <div className={styles.page}><p className={styles.state}>{error || 'Movie not found.'}</p></div>;

  const year = movie.releaseDate ? new Date(movie.releaseDate).getFullYear() : null;

  return (
    <div className={styles.hero}>
      <div className={styles.page}>
        <div className={styles.layout}>
          <div className={styles.posterFrame}>
            <div className={styles.sprockets} />
            {movie.posterUrl ? (
              <img className={styles.poster} src={movie.posterUrl} alt={movie.title} />
            ) : (
              <div className={styles.poster} />
            )}
            <div className={styles.sprockets} />
          </div>

          <div>
            <h1 className={styles.title}>{movie.title}</h1>
            <p className={styles.meta}>
              {[year, movie.runtimeMinutes ? `${movie.runtimeMinutes} min` : null, movie.voteAverage ? `★ ${movie.voteAverage.toFixed(1)} community` : null]
                .filter(Boolean)
                .join(' · ')}
            </p>

            {movie.genres?.length > 0 && (
              <div className={styles.genres}>
                {movie.genres.map((g) => <span key={g} className={styles.genreTag}>{g}</span>)}
              </div>
            )}

            <p className={styles.overview}>{movie.overview}</p>

            <div className={styles.actions}>
              <button className={styles.btnPrimary} onClick={handleLogClick}>Log film</button>
              <button
                className={`${styles.btnSecondary} ${onWatchlist ? styles.active : ''}`}
                onClick={handleWatchlistToggle}
                disabled={watchlistBusy}
              >
                {onWatchlist ? '✓ On watchlist' : '+ Watchlist'}
              </button>
            </div>

            {loggedConfirmation && <p className={styles.confirmation}>Logged — check your diary.</p>}
          </div>
        </div>

        <LogMovieModal
          movie={movie}
          isOpen={logModalOpen}
          onClose={() => setLogModalOpen(false)}
          onLogged={() => setLoggedConfirmation(true)}
        />
      </div>
    </div>
  );
}
