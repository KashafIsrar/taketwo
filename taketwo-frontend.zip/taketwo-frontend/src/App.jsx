import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar.jsx';
import DiscoverPage from './pages/DiscoverPage.jsx';
import MovieDetailsPage from './pages/MovieDetailsPage.jsx';
import DiaryPage from './pages/DiaryPage.jsx';
import LoginPage from './pages/LoginPage.jsx';
import RegisterPage from './pages/RegisterPage.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';

export default function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<DiscoverPage />} />
        <Route path="/movie/:tmdbId" element={<MovieDetailsPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route
          path="/diary"
          element={
            <ProtectedRoute>
              <DiaryPage />
            </ProtectedRoute>
          }
        />
      </Routes>
    </>
  );
}
