import axios from 'axios';

// In dev, '/api' goes through Vite's proxy (vite.config.js) to localhost:8080 —
// no CORS headaches, no hardcoded port in the client bundle. In a production
// build there's no dev proxy, so VITE_API_BASE_URL must point at the real
// deployed backend (set it in a .env.production file, e.g.
// VITE_API_BASE_URL=https://api.taketwo.app/api).
const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || '/api',
});

// Attach the JWT to every outgoing request, if we have one.
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('taketwo_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// A 401 means the token is missing/expired — clear it so the UI can
// redirect to login instead of silently failing every request after.
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('taketwo_token');
    }
    return Promise.reject(error);
  },
);

export default api;
