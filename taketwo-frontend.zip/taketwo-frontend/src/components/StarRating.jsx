import { useState } from 'react';
import styles from './StarRating.module.css';

const STAR_COUNT = 5;

/**
 * Half-star rating control. Click the left half of a star for a .5 value,
 * the right half for a whole value. Works as both an input (onChange) and
 * a read-only display (readOnly).
 */
export default function StarRating({ value = 0, onChange, readOnly = false, size = 26, showValue = false }) {
  const [hoverValue, setHoverValue] = useState(null);
  const displayValue = hoverValue ?? value;

  function handleInteraction(starIndex, event, commit) {
    if (readOnly || !onChange) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const isLeftHalf = event.clientX - rect.left < rect.width / 2;
    const next = starIndex + (isLeftHalf ? 0.5 : 1);
    if (commit) {
      onChange(next);
    } else {
      setHoverValue(next);
    }
  }

  return (
    <span className={styles.row} onMouseLeave={() => setHoverValue(null)}>
      {Array.from({ length: STAR_COUNT }).map((_, i) => {
        const fillPercent = Math.max(0, Math.min(1, displayValue - i)) * 100;
        return (
          <span
            key={i}
            className={`${styles.star} ${readOnly ? styles.readOnly : ''}`}
            style={{ width: size, height: size, fontSize: size }}
            onMouseMove={(e) => handleInteraction(i, e, false)}
            onClick={(e) => handleInteraction(i, e, true)}
            role={readOnly ? undefined : 'button'}
            aria-label={readOnly ? undefined : `Rate ${i + 1} stars`}
          >
            <span className={styles.starBase}>★</span>
            <span className={styles.starFill} style={{ width: `${fillPercent}%` }}>★</span>
          </span>
        );
      })}
      {showValue && <span className={styles.value}>{value ? value.toFixed(1) : '–'} / 5</span>}
    </span>
  );
}
